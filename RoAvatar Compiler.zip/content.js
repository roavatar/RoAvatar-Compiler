// content.js

function extractAllEmails() {
    const allEmails = [];
    console.log('Starting email extraction process...');

    const emailRows = document.querySelectorAll('tr.zA');
    console.log(`Found ${emailRows.length} emails.`);

    emailRows.forEach(row => {
        try {
            const senderElement = row.querySelector('.yX.xY .zF') || row.querySelector('.yW .zF');
            let senderEmail = 'Unknown Sender';
            if (senderElement) {
                const emailAttr = senderElement.getAttribute('email');
                senderEmail = emailAttr ? emailAttr : senderElement.textContent.trim();
            }

            const subjectElement = row.querySelector('.bog span');
            const subject = subjectElement ? subjectElement.textContent.trim() : 'No Subject';

            // Extract date from data-legacy-last-message-date attribute
            const dateTimestamp = row.getAttribute('data-legacy-last-message-date');
            let date;
            if (dateTimestamp) {
                date = new Date(parseInt(dateTimestamp)).toISOString();
            } else {
                date = new Date().toISOString();
            }

            const snippetElement = row.querySelector('.y2');
            const snippet = snippetElement ? snippetElement.textContent.trim() : 'No Snippet';

            allEmails.push({
                from: senderEmail,
                subject: subject,
                date: date,
                snippet: snippet
            });
        } catch (error) {
            console.error('Error extracting email details:', error);
        }
    });

    console.log('Extracted Emails:', allEmails);
    return allEmails;
}

function extractNewEmails(lastSentDate) {
    const allEmails = extractAllEmails();
    const newEmails = allEmails.filter(email => new Date(email.date) > new Date(lastSentDate));
    return newEmails;
}

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'extractAllEmails') {
        console.log('Received request to extract all emails');
        const emails = extractAllEmails();
        if (emails.length === 0) {
            console.warn('No emails found.');
        }
        sendResponse({ emails: emails });
    } else if (request.action === 'extractNewEmails') {
        console.log('Received request to extract new emails');
        const newEmails = extractNewEmails(request.lastSentDate);
        sendResponse({ emails: newEmails });
    }
    return true;
});
